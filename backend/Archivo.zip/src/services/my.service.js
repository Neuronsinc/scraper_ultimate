module.exports = {
	MyService
};